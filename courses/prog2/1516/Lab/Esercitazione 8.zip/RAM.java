package Esercitazione8;

class RAM extends Componente
{
	private int capacit�;
	private MainBoard schedaMadre;
	
	RAM(double prezzo, String modello, int capacit�)
	{
		super(prezzo, modello);
		this.capacit� = capacit�;
	}

	int getCapacit�()
	{
		return capacit�;
	}
	
	@Override
	boolean installa(Componente c)
	{
		boolean esito = false;
		if(c == null || !(c instanceof MainBoard))
			System.out.println("Errore: il componente su cui installare la memoria deve essere una MainBoard");
		else if(schedaMadre != null)
			System.out.println("Errore: il banco di memoria � gi� stato installato");
		else
		{
			MainBoard schedaMadre = (MainBoard)c;
			esito = schedaMadre.installaRAM(this);
			if(esito)
			{
				this.schedaMadre = schedaMadre;
				System.out.println("Banco di memoria installato correttamente");
			}
			else
				System.out.println("La scheda madre non ha banchi liberi.");
		}
		return esito;
	}

	@Override
	void disinstalla()
	{
		if(schedaMadre != null)
		{
			schedaMadre.disinstallaRAM(this);
			schedaMadre = null;
			System.out.println("RAM disinstallata correttamente.");
		}
		else
			System.out.println("Errore: RAM non installata!");		
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof RAM))
			return false;
		return super.equals(obj);
	}
	
	@Override
	public String toString()
	{
		return "ID: " + getId() + " - " + nome + " " + capacit� + "GB - �" + prezzo;
	}
}
