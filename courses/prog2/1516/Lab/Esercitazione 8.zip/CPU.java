package Esercitazione8;

class CPU extends Componente
{
	private float frequenza;
	private MainBoard schedaMadre;
	
	CPU(double prezzo, String modello, float frequenza)
	{
		super(prezzo, modello);
		this.frequenza = frequenza;
	}

	float getFrequenza()
	{
		return frequenza;
	}
	
	@Override
	boolean installa(Componente c)
	{
		boolean esito = false;
		if(c == null || !(c instanceof MainBoard))
			System.out.println("Errore: il componente su cui installare la CPU deve essere una MainBoard");
		else if(schedaMadre != null)
			System.out.println("Errore: la CPU � gi� stata installata");
		else
		{
			MainBoard schedaMadre = (MainBoard)c;
			esito = schedaMadre.installaCPU(this);
			if(esito)
			{
				this.schedaMadre = schedaMadre;
				System.out.println("CPU installata correttamente");
			}
			else
				System.out.println("La scheda madre ha gi� una CPU.");
		}
		return esito;
	}

	@Override
	void disinstalla()
	{
		if(schedaMadre != null)
		{
			schedaMadre.disinstallaCPU();
			schedaMadre = null;
			System.out.println("CPU disinstallata correttamente.");
		}
		else
			System.out.println("Errore: CPU non installata!");		
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof CPU))
			return false;
		return super.equals(obj);
	}
	
	@Override
	public String toString()
	{
		return "ID: " + getId() + " - " + nome + " " + frequenza + "Ghz - �" + prezzo;
	}
}
