package Esercitazione8;

import java.util.Comparator;

abstract class Componente implements Comparable
{
	private static int idGlobale = 0;
	private int id;
	protected String nome;
	protected double prezzo;
		
	abstract boolean installa(Componente c);
	abstract void disinstalla();
	
	Componente(double prezzo)
	{
		this(prezzo, "Componente generico");
	}
	
	Componente(double prezzo, String nome)
	{
		this.prezzo = prezzo;
		this.nome = nome;
		this.id = ++idGlobale;
	}
	
	int getId()
	{
		return id;
	}
	
	String getNome()
	{
		return nome;
	}
	
	double getPrezzo()
	{
		return prezzo;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof Componente))
			return false;
		
		Componente altroComponente = (Componente) obj;
		if (id != altroComponente.id)
			return false;
		return true;
	}
	
	@Override
	public int compareTo(Object altro)
	{
		if(altro == null || !(altro instanceof Componente))
			return -1;
		else
		{
			Componente altroC = (Componente)altro;
			if(prezzo == altroC.prezzo)
				return nome.compareTo(altroC.nome);
			else
				return -((Double)prezzo).compareTo(altroC.prezzo);
		}
	}
	
	public static Comparator getPrezzoOrdering(boolean asc)
	{
		return new PrezzoOrdering(asc);
	}

	public static Comparator getNomeOrdering(boolean asc)
	{
		return new NomeOrdering(asc);
	}

}

class PrezzoOrdering implements Comparator
{
	private int sign = 1;
	
	PrezzoOrdering(boolean asc)
	{
		if(!asc)
			sign = -1;
	}
	
	@Override
	public int compare(Object arg0, Object arg1)
	{
		Componente s1 = (Componente) arg0;
		Componente s2 = (Componente) arg1;
		return sign * ((Double)s1.prezzo).compareTo(s2.prezzo);
	}
}

class NomeOrdering implements Comparator
{
	private int sign = 1;
	
	NomeOrdering(boolean asc)
	{
		if(!asc)
			sign = -1;
	}
	
	@Override
	public int compare(Object arg0, Object arg1)
	{
		Componente s1 = (Componente) arg0;
		Componente s2 = (Componente) arg1;
		return sign*s1.nome.compareTo(s2.nome);
	}
}

