package Esercitazione8;

import java.util.Arrays;
import java.util.Random;

public class Test
{
	public static void main(String args[])
	{
		Componente comps[] = new Componente[100];
		Random rand = new Random();
		for(int i=0; i<comps.length; i++)
		{
			int num = rand.nextInt(3);
			if(num == 0)
				comps[i] = new MainBoard(rand.nextInt(50)+100, "Main"+ i, rand.nextInt(4)+1);
			else if(num == 1)
				comps[i] = new RAM(rand.nextInt(50)+50, "RAM"+ i, (int)Math.pow(2, rand.nextInt(4)));
			else if(num == 2)
				comps[i] = new CPU(rand.nextInt(150)+100, "CPU"+ i, (int)rand.nextFloat()*3+1);			
		}
		
		Arrays.sort(comps);
		for(Componente c:comps)
			System.out.println(c);
		
		Arrays.sort(comps, Componente.getPrezzoOrdering(true));
		for(Componente c:comps)
			System.out.println(c);
		
		Arrays.sort(comps, Componente.getNomeOrdering(true));
		for(Componente c:comps)
			System.out.println(c);
		
		Arrays.sort(comps, Componente.getNomeOrdering(false));
		for(Componente c:comps)
			System.out.println(c);
	}
}
