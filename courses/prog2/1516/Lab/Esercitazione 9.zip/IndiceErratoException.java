package Esercitazione9;

public class IndiceErratoException extends Exception
{
	public IndiceErratoException ()
	{
		
	}
	
	public IndiceErratoException(String string)
	{
		super(string);
	}
	
}
