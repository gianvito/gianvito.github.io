package Esercitazione9;

import java.util.Random;

import Esercitazione8.*;

public class TestCollezione
{
	public static void main(String args[])
	{
		Collezione<Componente> coll = new Collezione<>(100);
				
		Random rand = new Random();
		for(int i=0; i<50; i++)
		{
			int num = rand.nextInt(3);
			Componente comp = null;
			if(num == 0)
				comp = new MainBoard(rand.nextInt(50)+100, "Main"+ i, rand.nextInt(4)+1);
			else if(num == 1)
				comp = new RAM(rand.nextInt(50)+50, "RAM"+ i, (int)Math.pow(2, rand.nextInt(4)));
			else if(num == 2)
				comp = new CPU(rand.nextInt(150)+100, "CPU"+ i, (int)rand.nextFloat()*3+1);
			
			try
			{
				coll.aggiungi(comp);
			}
			catch(CollezionePienaException e)
			{
				System.out.println("Impossibile aggiungere altri elementi");
				break;
			}
		}
		
		try
		{
			coll.rimuovi(5);
		}
		catch (IndiceErratoException e)
		{
			System.out.println("Impossibile eliminare un elemento");
		}
		
		try
		{
			coll.scambia(10, 80);;
		}
		catch (IndiceErratoException e)
		{
			System.out.println(e.getMessage());
		}
		
		System.out.println("Completato");
	}
}
