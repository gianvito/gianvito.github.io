package Esercitazione9;

import java.util.Arrays;

public class Collezione<T>
{
	private T [] collezione;
	private int numElem = 0;
	
	public Collezione(int size)
	{
		collezione = (T[])new Object[size];
	}
	
	public void aggiungi(T elem) throws CollezionePienaException
	{
		if(numElem == collezione.length)
			throw new CollezionePienaException();
		
		collezione[numElem] = elem;
		numElem++;
	}
	
	public void rimuovi(int pos) throws IndiceErratoException
	{
		if(pos < 0 || pos>=numElem)
			throw new IndiceErratoException();
		
		for(int i=pos; i<numElem-1; i++)
			collezione[i] = collezione[i+1];
		collezione[numElem] = null;
		numElem--;
	}
	
	public int numElementi()
	{
		return numElem;
	}
	
	public void scambia(int i, int j) throws IndiceErratoException
	{
		if(i<0 || i >= numElem)
			throw new IndiceErratoException("Errore nello scambio dovuto al primo indice: " + i);
		else if(j<0 || j >= numElem)
			throw new IndiceErratoException("Errore nello scambio dovuto al secondo indice:  " + j);
		
		T temp = collezione[i];
		collezione[i] = collezione[j];
		collezione[j] = temp;
	}
	
	@Override
	public String toString()
	{
		String res = "[";
		for(int i=0; i<numElem; i++)
			res += collezione[i] + ", ";
		res = res.substring(0, res.length()-2);
		res += "]";
		
		return res;
	}

	
	@Override
	public boolean equals(Object altro)
	{
		if(altro == null || !(altro instanceof Collezione))
			return false;
		else
		{
			Collezione altraCollezione = (Collezione) altro;
			return Arrays.equals(collezione, altraCollezione.collezione);
		}
	}
}
