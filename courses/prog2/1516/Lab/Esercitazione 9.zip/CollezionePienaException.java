package Esercitazione9;

public class CollezionePienaException extends Exception { }
