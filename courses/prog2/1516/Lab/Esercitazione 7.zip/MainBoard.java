package Esercitazione7;

class MainBoard extends Componente
{
	private double altezza;
	private double larghezza;
	private int slotsOccupati;
	private boolean installata;
	private CPU cpu;
	private RAM banchi[];
	
	MainBoard(double prezzo, String modello, int numSlots)
	{
		this(prezzo, modello, numSlots, 0, 0);
	}
	
	MainBoard(double prezzo, String modello, int numSlots, double altezza, double larghezza)
	{
		super(prezzo, modello);
		this.altezza = altezza;
		this.larghezza = larghezza;
		banchi = new RAM[numSlots];
		slotsOccupati = 0;
	}

	public double getAltezza()
	{
		return altezza;
	}

	public double getLarghezza()
	{
		return larghezza;
	}

	public int getNumSlots()
	{
		return banchi.length;
	}
	
	@Override
	boolean installa(Componente c)
	{
		if(c != null)
		{
			System.out.println("Errore: impossibile installare una scheda madre su un altro componente.");
			return false;
		}
		else if(installata)
		{
			System.out.println("Errore: scheda madre gi� installata.");
			return false;
		}
		else
		{
			installata = true;
			System.out.println("Scheda madre installata correttamente.");
			return true;
		}
	}

	@Override
	void disinstalla()
	{
		if(installata)
		{
			installata = false;
			System.out.println("Scheda madre disinstallata correttamente.");
		}
		else
			System.out.println("Errore: scheda madre non installata!");		
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof MainBoard))
			return false;
		return super.equals(obj);
	}

	int getSlotLiberi()
	{
		return banchi.length - slotsOccupati;
	}

	
	
	boolean installaCPU(CPU cpu)
	{
		if (this.cpu == null)
		{
			this.cpu = cpu;
			return true;
		}
		else
			return false;
		
	}
	
	boolean disinstallaCPU()
	{
		if(cpu == null)
			return false;
		else
		{
			this.cpu = null;
			return true;
		}
	}

	
	boolean installaRAM(RAM banco)
	{
		if(slotsOccupati == banchi.length)
			return false;
		else
		{
			banchi[slotsOccupati] = banco;
			slotsOccupati++;
			return true;
		}
	}
	
	void disinstallaRAM(RAM banco)
	{
		int i = 0;
		while(i < slotsOccupati && banchi[i].equals(banco))
			i++;
		
		if(i < slotsOccupati)
		{
			for(int j = i; j < slotsOccupati - 1; j++)
				banchi[j] = banchi[j+1];
		}
		slotsOccupati--;
	}
}
