package Esercitazione7;

public class Test
{

	public static void main(String args[])
	{
		MainBoard mb = new MainBoard(100, "Asus", 4);
		RAM b1 = new RAM(20, "Corsair", 2);
		RAM b2 = new RAM(20, "Corsair", 2);
		RAM b3 = new RAM(20, "Corsair", 2);
		RAM b4 = new RAM(20, "Corsair", 2);
		RAM b5 = new RAM(20, "Corsair", 2);
		CPU cpu = new CPU(100, "Intel i7", 3);
		CPU cpu2 = new CPU(100, "AMD", 3);
		
		mb.installa(null);
		b1.installa(mb);
		b2.installa(mb);
		b3.installa(mb);

		
		cpu.installa(mb);
//		mb.disinstallaCPU();
		cpu2.installa(mb);
		mb.disinstallaCPU();
		cpu2.installa(mb);
	}
}
