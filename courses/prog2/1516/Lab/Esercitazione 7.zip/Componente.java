package Esercitazione7;

class Componente
{
	private static int idGlobale = 0;
	private int id;
	protected String nome;
	protected double prezzo;
		
	boolean installa(Componente c) {return true;};
	void disinstalla() {};
	
	Componente(double prezzo)
	{
		this(prezzo, "Componente generico");
	}
	
	Componente(double prezzo, String nome)
	{
		this.prezzo = prezzo;
		this.nome = nome;
		this.id = ++idGlobale;
	}
	
	int getId()
	{
		return id;
	}
	
	String getNome()
	{
		return nome;
	}
	
	double getPrezzo()
	{
		return prezzo;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof Componente))
			return false;
		
		Componente altroComponente = (Componente) obj;
		if (id != altroComponente.id)
			return false;
		return true;
	}
}
